package com.example.chikui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class DetailActivity extends AppCompatActivity {
    private Spinner show_list;
    public String[] kind = null;
    private Handler handler,handler1;
    private contentDBManger[] allWeb = null,showWeb = null;
    private ListView show_web;
    private String data = null;
    private TextView Tip;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail);
        Intent intent = getIntent();
        String user_name = intent.getStringExtra("name");
        Toast.makeText(this,user_name + " 欢迎你",Toast.LENGTH_SHORT).show();
        show_list = (Spinner)findViewById(R.id.show_list);
        show_web = (ListView) findViewById(R.id.show_web);
        Tip = (TextView)findViewById(R.id.Tip);

        handler = new MyHandler();
        Thread t = new MyThread();
        t.start();

        show_list.setSelection(0,true);
        show_list.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                data = (String)show_list.getItemAtPosition(position);
                handler1 = new MyHandler1();
                Thread t1 = new MyThread1();
                t1.start();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        show_web.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String weburl = showWeb[position].getweburl();
                Intent intent = new Intent(DetailActivity.this,ContentActivity.class);
                intent.putExtra("url",weburl);
                startActivity(intent);
            }
        });
    }
    class MyThread extends Thread{
        @Override
        public void run() {
            try {
                kind = VisitDB.select();
                Message message = handler.obtainMessage();
                message.obj = kind;
                handler.sendMessage(message);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    class MyHandler extends Handler{
        @Override
        public void handleMessage(Message msg){
            super.handleMessage(msg);
            String[] array = (String[]) msg.obj;
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(DetailActivity.this, android.R.layout.simple_spinner_item,array);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            show_list.setAdapter(adapter);
        }
    }


    class MyThread1 extends Thread{
        @Override
        public void run() {
            try {
                allWeb = VisitDB.query(data);
                Message message = handler1.obtainMessage();
                message.obj = allWeb;
                handler1.sendMessage(message);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    class MyHandler1 extends Handler{
        @Override
        public void handleMessage(Message msg){
            super.handleMessage(msg);
            showWeb = (contentDBManger[]) msg.obj;
            webAdapter adapter = new webAdapter(DetailActivity.this,R.layout.web_item ,showWeb);
            show_web.setAdapter(adapter);
        }
    }
}