package com.example.chikui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.widget.Toast;

public class ContentActivity extends AppCompatActivity {
    private WebView webView;
    //private TextView show_url;
    private String url;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_content);
        webView = (WebView)findViewById(R.id.webView);
        //show_url = (TextView)findViewById(R.id.show_url);
        Intent intent = getIntent();
        url = intent.getStringExtra("url");
        //show_url.setText(url);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setWebViewClient(new WebViewClient(){
            @Override
            public boolean shouldOverrideUrlLoading(WebView view,String weburl){
                view.loadUrl(weburl);
                return true;
            }
        });
        webView.loadUrl(url);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView.canGoBack()) {
            webView.goBack();// activityBaseWebAddWebView.reload();
            webView.removeAllViews();//删除webview中所以进程
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}