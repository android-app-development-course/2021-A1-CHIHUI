package com.example.chikui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class DBConnection {
    //要连接的数据库url,注意：此处连接的应该是服务器上的MySQl的地址
    private static String url = "jdbc:mysql://47.119.132.220:3306/project";
    //连接数据库使用的用户名
    private static String userName = "root";
    //连接的数据库时使用的密码
    private static String userPassword = "25574201Abc/";
    private static Connection connection = null;



    public static void insert (String name,String password){
        try {
            //1、加载驱动
            Class.forName("com.mysql.jdbc.Driver").newInstance();
        }catch (Exception e){
            e.printStackTrace();
        }
        try {
            //2、获取与数据库的连接
            connection = DriverManager.getConnection(url, userName, userPassword);
            //3.sql语句
            String sql = "INSERT INTO User_name (id,username,password) VALUES (DEFAULT,'"+name+"','"+password+"')";
            //4.获取用于向数据库发送sql语句的ps
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.execute(sql);
        }catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            if(connection!=null){
                try {
                    connection.close();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }
    }

    public static String query_password(String name){
        String password = null;
        try {
            //1、加载驱动
            Class.forName("com.mysql.jdbc.Driver").newInstance();
        }catch (Exception e){
            e.printStackTrace();
        }
        try {
            //2、获取与数据库的连接
            connection = DriverManager.getConnection(url, userName, userPassword);
            //3.sql语句
            String sql = "select * from User_name where username = '"+name+"'";
            //4.获取用于向数据库发送sql语句的ps
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery(sql);
            if(rs.next()){
                password = rs.getString("password");
            }
        }catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            if(connection!=null){
                try {
                    connection.close();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }
        return password;
    }

    public static int query_name(String name){
        String password = null;
        try {
            //1、加载驱动
            Class.forName("com.mysql.jdbc.Driver").newInstance();
        }catch (Exception e){
            e.printStackTrace();
        }
        try {
            //2、获取与数据库的连接
            connection = DriverManager.getConnection(url, userName, userPassword);
            //3.sql语句
            String sql = "select * from User_name where username = '"+name+"'";
            //4.获取用于向数据库发送sql语句的ps
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery(sql);
            if(rs.next()){
                return 1;
            }
            else {
                return 0;
            }
        }catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            if(connection!=null){
                try {
                    connection.close();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }
        return 0;
    }
}
