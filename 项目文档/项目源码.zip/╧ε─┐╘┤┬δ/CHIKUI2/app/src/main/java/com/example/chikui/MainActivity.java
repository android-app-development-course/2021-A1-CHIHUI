package com.example.chikui;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    SQLiteDatabase db;
    private Button login,register;
    private EditText username,password;
    private String user_name,user_password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {//隐藏标题
            actionBar.hide();
        }
        login = (Button)findViewById(R.id.login);
        register = (Button)findViewById(R.id.register);
        username = (EditText)findViewById(R.id.username);
        password = (EditText)findViewById(R.id.password);

        Intent intent1 = new Intent(this,RegisterActivity.class);
        Intent intent2 = new Intent(this,DetailActivity.class);
        //登录事件
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                user_name = username.getText().toString();
                user_password = password.getText().toString();
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        if (user_password.equals(DBConnection.query_password(user_name))){
                            intent2.putExtra("name",user_name);
                            startActivity(intent2);
                            overridePendingTransition(R.anim.anim_in, R.anim.anim_out);
                            username.setText("");
                            password.setText("");
                            //password.setText("");
                        }
                        else if (DBConnection.query_password(user_name) == null){
                            Looper.prepare();
                            Toast.makeText(MainActivity.this,"没有该用户信息",Toast.LENGTH_SHORT).show();
                            username.setText("");
                            password.setText("");
                            Looper.loop();
                        }
                        else{
                            Looper.prepare();
                            Toast.makeText(MainActivity.this,"密码错误",Toast.LENGTH_SHORT).show();
                            password.setText("");
                            Looper.loop();
                        }
                    }
                }).start();
            }
        });
        //注册事件
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intent1);
                overridePendingTransition(R.anim.anim_in, R.anim.anim_out);
            }
        });
    }
}