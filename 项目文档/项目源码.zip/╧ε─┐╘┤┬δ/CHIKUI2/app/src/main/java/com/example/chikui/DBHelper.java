package com.example.chikui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBHelper {
    private static Connection conn;
    private static String DB_Username = "root";
    private static String DB_Password = "25574201Abc/";
    private  static String DB_Url = "jdbc:mysql://47.119.132.220:3306/project";

    public static Connection getConnection(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        try{
            conn = DriverManager.getConnection(DB_Url,DB_Username,DB_Password);
            return conn;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
}
