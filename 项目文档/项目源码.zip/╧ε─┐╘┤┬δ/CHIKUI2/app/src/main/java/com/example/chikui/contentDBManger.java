package com.example.chikui;

public class contentDBManger {
    private  String imgUrl;
    private  String Kind;
    private  String webName;
    private  String webUrl;
    private  String webDiscuss;

    public contentDBManger(){
        imgUrl =  null;
        Kind = null;
        webName = null;
        webUrl = null;
        webDiscuss = null;
    }

    public contentDBManger(String imgurl,String kind,String webname,String weburl,String webdiscuss){
        imgUrl = imgurl;
        Kind = kind;
        webName = webname;
        webUrl = weburl;
        webDiscuss = webdiscuss;
    }
    public String getImgurl(){
        return imgUrl;
    }
    public void setId(String imgurl){
        this.imgUrl = imgurl;
    }
    public String getKind(){
        return Kind;
    }
    public void setKind(String kind){
        this.Kind = kind;
    }
    public String getwebName(){
        return webName;
    }
    public void setWebName(String webname){
        this.webName = webname;
    }
    public String getweburl(){
        return webUrl;
    }
    public void setWebUrl(String weburl) {
        this.webUrl = weburl;
    }
    public String getwebDiscuss(){
        return webDiscuss;
    }
    public void setwebDiscuss(String webdiscuss){
        this.webDiscuss = webdiscuss;
    }
}
