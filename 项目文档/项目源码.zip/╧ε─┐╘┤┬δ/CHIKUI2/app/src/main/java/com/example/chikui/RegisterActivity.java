package com.example.chikui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {
    private EditText username,password,again_password;
    private Button register;
    String u_name,u_password,a_u_password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);
        username = (EditText)findViewById(R.id.username);
        password = (EditText)findViewById(R.id.password);
        again_password = (EditText)findViewById(R.id.again_password);
        register = (Button)findViewById(R.id.register);
        overridePendingTransition(R.anim.anim_out, R.anim.anim_in);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                u_name = username.getText().toString();
                u_password = password.getText().toString();
                a_u_password = again_password.getText().toString();
                if(username.getText().toString().trim().length() == 0){
                    Toast.makeText(RegisterActivity.this,"请输入用户名",Toast.LENGTH_SHORT).show();
                }
                else if(password.getText().toString().trim().length() == 0){
                    Toast.makeText(RegisterActivity.this,"请输入密码",Toast.LENGTH_SHORT).show();
                }
                else if(again_password.getText().toString().trim().length() == 0){
                    Toast.makeText(RegisterActivity.this,"请再次输入密码",Toast.LENGTH_SHORT).show();
                }
                else{
                    if(a_u_password.equals(u_password)){
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                if(DBConnection.query_name(u_name) == 0) {
                                    DBConnection.insert(u_name, u_password);
                                    Looper.prepare();
                                    Toast.makeText(RegisterActivity.this,"注册成功",Toast.LENGTH_SHORT).show();
                                    RegisterActivity.this.finish();
                                    Looper.loop();
                                }
                                else {
                                    Looper.prepare();
                                    Toast.makeText(RegisterActivity.this,"用户名重复，请再想一个吧",Toast.LENGTH_SHORT).show();
                                    username.setText("");
                                    password.setText("");
                                    again_password.setText("");
                                    Looper.loop();
                                }
                            }
                        }).start();
                    }
                    else{
                        Toast.makeText(RegisterActivity.this,"两次密码不相同",Toast.LENGTH_SHORT).show();
                        username.setText("");
                        password.setText("");
                        again_password.setText("");
                    }
                }
            }
        });
    }
}