package com.example.chikui;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.xml.transform.Result;

public class VisitDB {
    private static Connection conn;
    private static Statement stm;
    private static ResultSet rs;

    public static String[] select(){
        try{
            conn = DBHelper.getConnection();
            if(conn == null){
                return null;
            }
            String sql = "select distinct webKind from content";
            stm = conn.createStatement();
            rs = stm.executeQuery(sql);
            int i = 0;
            while(rs.next()){
                i++;
            }
            rs.beforeFirst();
            String[] kind = new String[i];
            i = 0;
            while(rs.next()){
                kind[i] = rs.getString(1);
                i++;
            }
            return kind;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }finally {
            try{
                stm.close();
                conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static contentDBManger[] query(String name){
        try{
            conn = DBHelper.getConnection();
            if(conn == null){
                return null;
            }
            String sql = "select * from content where webKind = '"+name+"'";
            stm = conn.createStatement();
            rs = stm.executeQuery(sql);
            int i = 0;
            while(rs.next()){
                i++;//i++;
            }
            rs.beforeFirst();
            contentDBManger[] content = new contentDBManger[i];
            i = 0;
            while(rs.next()){
                content[i] = new contentDBManger(rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6));
                i++;
            }
            return content;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }finally {
            try{
                stm.close();
                conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}