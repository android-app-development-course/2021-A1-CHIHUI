package com.example.chikui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.loopj.android.image.SmartImageView;

import java.util.List;


public class webAdapter extends ArrayAdapter {
    private final int res;
    public webAdapter(Context context, int resource, contentDBManger[] object) {
        super(context, resource,object);
        res = resource;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        contentDBManger dbManger = (contentDBManger)getItem(position);
        View view = LayoutInflater.from(getContext()).inflate(res,null);
        TextView title = (TextView) view.findViewById(R.id.title);
        TextView discuss = (TextView) view.findViewById(R.id.discuss);
        SmartImageView webImg = (SmartImageView) view.findViewById(R.id.webImg);
        title.setText(dbManger.getwebName());
        discuss.setText(dbManger.getwebDiscuss());
        webImg.setImageUrl(dbManger.getImgurl(),R.mipmap.ic_launcher_round,R.mipmap.ic_launcher_round);
        return view;
    }
}
